Ejecutar el archivo Tarea1.ipynb con la base de datos spotify.npy en la misma carpeta.
